# -*- coding: utf-8 -*-
"""
Translation Services - Support for multiple translation APIs.
"""

import json
import urllib.request
import urllib.parse
import xbmc


def get_translator(service_name, config):
    """
    Get a translator instance for the specified service.
    
    Args:
        service_name: Name of the translation service
        config: Service configuration dict
    
    Returns:
        Translator instance
    """
    translators = {
        'deepl': DeepLTranslator,
        'deepl_free': DeepLTranslator,
        'libretranslate': LibreTranslateTranslator,
        'mymemory': MyMemoryTranslator,
        'google': GoogleTranslator,
        'microsoft': MicrosoftTranslator,
        'lingva': LingvaTranslator,
        'openai': OpenAITranslator,
        'anthropic': AnthropicTranslator,
        'argos': ArgosTranslator,
    }
    
    translator_class = translators.get(service_name, LibreTranslateTranslator)
    return translator_class(config)


class BaseTranslator:
    """Base class for translation services."""
    
    # Max parallel workers for non-batch APIs (override in subclass)
    MAX_WORKERS = 1
    
    def __init__(self, config):
        self.config = config
        self.timeout = config.get('timeout', 30)
    
    def translate(self, text, source_lang, target_lang):
        """Translate a single text string."""
        raise NotImplementedError
    
    def translate_batch(self, texts, source_lang, target_lang):
        """
        Translate multiple texts.
        Default: parallel execution with ThreadPoolExecutor for non-batch APIs.
        Subclasses with native batch APIs should override this directly.
        """
        if self.MAX_WORKERS <= 1 or len(texts) <= 1:
            return [self.translate(text, source_lang, target_lang) for text in texts]
        
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        workers = min(self.MAX_WORKERS, len(texts))
        results = [None] * len(texts)
        
        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_to_idx = {
                pool.submit(self.translate, text, source_lang, target_lang): i
                for i, text in enumerate(texts)
            }
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    results[idx] = future.result()
                except Exception as e:
                    self._log(f"Parallel translate error [{idx}]: {e}", xbmc.LOGERROR)
                    results[idx] = texts[idx]  # fallback to original
        
        return results
    
    def _request(self, url, data=None, headers=None, method='POST'):
        """Make HTTP request."""
        if headers is None:
            headers = {}
        
        if data and isinstance(data, dict):
            data = json.dumps(data).encode('utf-8')
            headers['Content-Type'] = 'application/json'
        elif data and isinstance(data, str):
            data = data.encode('utf-8')
        
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return json.loads(response.read().decode('utf-8'))
        except Exception as e:
            self._log(f"Request error: {e}", xbmc.LOGERROR)
            raise
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message."""
        xbmc.log(f"[Translator] {message}", level)


class DeepLTranslator(BaseTranslator):
    """DeepL Translation API."""
    
    def __init__(self, config):
        super().__init__(config)
        self.api_key = config.get('api_key', '')
        self.formality = config.get('formality', 'default')
        self.is_free = config.get('free', False)
        
        if self.is_free:
            self.base_url = 'https://api-free.deepl.com/v2'
        else:
            self.base_url = 'https://api.deepl.com/v2'
    
    def translate(self, text, source_lang, target_lang):
        """Translate text using DeepL."""
        if not self.api_key:
            raise ValueError("DeepL API key required")
        
        result = self.translate_batch([text], source_lang, target_lang)
        return result[0] if result else text
    
    def translate_batch(self, texts, source_lang, target_lang):
        """Translate multiple texts in one request."""
        if not self.api_key:
            raise ValueError("DeepL API key required")
        
        # Map language codes
        target = self._map_language(target_lang)
        source = self._map_language(source_lang) if source_lang != 'auto' else None
        
        data = {
            'text': texts,
            'target_lang': target
        }
        
        if source:
            data['source_lang'] = source

        # Default to informal for Spanish (TaMaBin style uses "tú")
        formality = self.formality
        if formality == 'default' and target.upper().startswith('ES'):
            formality = 'less'

        # DeepL supports formality for these target languages (including regional variants)
        formality_targets = ['DE', 'FR', 'IT', 'ES', 'ES-419', 'NL', 'PL', 'PT-PT', 'PT-BR', 'RU']
        if formality != 'default' and target.upper() in formality_targets:
            data['formality'] = formality
        
        headers = {
            'Authorization': f'DeepL-Auth-Key {self.api_key}'
        }
        
        try:
            response = self._request(f'{self.base_url}/translate', data, headers)
            results = [t['text'] for t in response.get('translations', [])]
            return self._post_process_spanish(results, target)
        except Exception as e:
            self._log(f"DeepL error: {e}", xbmc.LOGERROR)
            return texts
    
    def _post_process_spanish(self, texts, target_lang):
        """Apply TaMaBin-style post-processing for Spanish translations."""
        if not target_lang.upper().startswith('ES'):
            return texts

        import re

        processed = []
        for text in texts:
            # Fix dialogue format: ensure "- " (dash + space) not "—" or "-text"
            lines = text.split('\n')
            fixed_lines = []
            for line in lines:
                line = line.strip()
                # Convert em-dash or en-dash to "- "
                if line.startswith('\u2014') or line.startswith('\u2013'):
                    line = '- ' + line[1:].lstrip()
                # Ensure space after leading dash
                elif line.startswith('-') and len(line) > 1 and line[1] != ' ':
                    line = '- ' + line[1:]
                fixed_lines.append(line)
            text = '\n'.join(fixed_lines)

            # Fix "solo" -> "sólo" (classical orthography)
            text = re.sub(r'\bsolo\b', 'sólo', text)
            text = re.sub(r'\bSolo\b', 'Sólo', text)

            # Ensure opening punctuation marks
            # Add ¿ if line has ? but no ¿
            for line in text.split('\n'):
                if '?' in line and '\u00bf' not in line:
                    # Find the start of the question
                    q_idx = line.rfind('?')
                    # Simple heuristic: add ¿ at start of sentence or after last period/comma
                    start = max(line.rfind('.', 0, q_idx), line.rfind(',', 0, q_idx), line.rfind('!', 0, q_idx)) + 1
                    if start == 0 and not line.startswith('- '):
                        text = text.replace(line, '\u00bf' + line.lstrip(), 1)
                    elif start > 0:
                        before = line[:start].rstrip() + ' '
                        after = '\u00bf' + line[start:].lstrip()
                        text = text.replace(line, before + after, 1)

            processed.append(text)

        return processed

    def _map_language(self, lang):
        """Map language code to DeepL format."""
        mapping = {
            'en': 'EN', 'sv': 'SV', 'de': 'DE', 'fr': 'FR',
            'es': 'ES-419', 'it': 'IT', 'nl': 'NL', 'pl': 'PL',
            'pt': 'PT-PT', 'ru': 'RU', 'ja': 'JA', 'zh': 'ZH',
            'da': 'DA', 'fi': 'FI', 'no': 'NB', 'ko': 'KO'
        }
        return mapping.get(lang.lower(), lang.upper())


class LibreTranslateTranslator(BaseTranslator):
    """LibreTranslate API (self-hosted or public instances)."""
    
    MAX_WORKERS = 4  # Parallel requests
    
    def __init__(self, config):
        super().__init__(config)
        self.base_url = config.get('url', 'https://libretranslate.com').rstrip('/')
        self.api_key = config.get('api_key', '')
    
    def translate(self, text, source_lang, target_lang):
        """Translate text using LibreTranslate."""
        data = {
            'q': text,
            'source': source_lang if source_lang != 'auto' else 'auto',
            'target': target_lang,
            'format': 'text'
        }
        
        if self.api_key:
            data['api_key'] = self.api_key
        
        try:
            response = self._request(f'{self.base_url}/translate', data)
            return response.get('translatedText', text)
        except Exception as e:
            self._log(f"LibreTranslate error: {e}", xbmc.LOGERROR)
            return text


class MyMemoryTranslator(BaseTranslator):
    """MyMemory Translation API (free, rate-limited)."""
    
    MAX_WORKERS = 2  # Gentle parallelism (free tier)
    
    def __init__(self, config):
        super().__init__(config)
        self.base_url = 'https://api.mymemory.translated.net'
        self.email = config.get('email', '')  # Optional, increases rate limit
    
    def translate(self, text, source_lang, target_lang):
        """Translate text using MyMemory."""
        # MyMemory doesn't support 'auto' - default to English
        source = source_lang if source_lang and source_lang != 'auto' else 'en'
        lang_pair = f'{source}|{target_lang}'
        
        params = {
            'q': text,
            'langpair': lang_pair
        }
        
        if self.email:
            params['de'] = self.email
        
        url = f'{self.base_url}/get?{urllib.parse.urlencode(params)}'
        
        try:
            response = self._request(url, method='GET')
            return response.get('responseData', {}).get('translatedText', text)
        except Exception as e:
            self._log(f"MyMemory error: {e}", xbmc.LOGERROR)
            return text


class GoogleTranslator(BaseTranslator):
    """Google Cloud Translation API."""
    
    def __init__(self, config):
        super().__init__(config)
        self.api_key = config.get('api_key', '')
        self.base_url = 'https://translation.googleapis.com/language/translate/v2'
    
    def translate(self, text, source_lang, target_lang):
        """Translate text using Google Cloud Translation."""
        if not self.api_key:
            raise ValueError("Google API key required")
        
        result = self.translate_batch([text], source_lang, target_lang)
        return result[0] if result else text
    
    def translate_batch(self, texts, source_lang, target_lang):
        """Translate multiple texts."""
        if not self.api_key:
            raise ValueError("Google API key required")
        
        data = {
            'q': texts,
            'target': target_lang,
            'format': 'text',
            'key': self.api_key
        }
        
        if source_lang != 'auto':
            data['source'] = source_lang
        
        try:
            response = self._request(self.base_url, data)
            translations = response.get('data', {}).get('translations', [])
            return [t.get('translatedText', texts[i]) for i, t in enumerate(translations)]
        except Exception as e:
            self._log(f"Google Translate error: {e}", xbmc.LOGERROR)
            return texts


class MicrosoftTranslator(BaseTranslator):
    """Microsoft Azure Translator API."""
    
    def __init__(self, config):
        super().__init__(config)
        self.api_key = config.get('api_key', '')
        self.region = config.get('region', 'westeurope')
        self.base_url = 'https://api.cognitive.microsofttranslator.com/translate'
    
    def translate(self, text, source_lang, target_lang):
        """Translate text using Microsoft Translator."""
        if not self.api_key:
            raise ValueError("Microsoft API key required")
        
        result = self.translate_batch([text], source_lang, target_lang)
        return result[0] if result else text
    
    def translate_batch(self, texts, source_lang, target_lang):
        """Translate multiple texts."""
        if not self.api_key:
            raise ValueError("Microsoft API key required")
        
        params = {
            'api-version': '3.0',
            'to': target_lang
        }
        
        if source_lang != 'auto':
            params['from'] = source_lang
        
        url = f'{self.base_url}?{urllib.parse.urlencode(params)}'
        
        headers = {
            'Ocp-Apim-Subscription-Key': self.api_key,
            'Ocp-Apim-Subscription-Region': self.region
        }
        
        data = [{'Text': text} for text in texts]
        
        try:
            response = self._request(url, data, headers)
            return [r['translations'][0]['text'] for r in response]
        except Exception as e:
            self._log(f"Microsoft Translator error: {e}", xbmc.LOGERROR)
            return texts


class LingvaTranslator(BaseTranslator):
    """Lingva Translate (free, open-source Google Translate frontend)."""
    
    MAX_WORKERS = 3  # Parallel but gentle (free service)
    
    def __init__(self, config):
        super().__init__(config)
        self.base_url = config.get('url', 'https://lingva.ml').rstrip('/')
        self._consecutive_429 = 0
    
    def translate(self, text, source_lang, target_lang):
        """Translate a single text using Lingva."""
        source = source_lang if source_lang and source_lang != 'auto' else 'en'
        encoded_text = urllib.parse.quote(text)
        url = f'{self.base_url}/api/v1/{source}/{target_lang}/{encoded_text}'
        
        try:
            response = self._request(url, method='GET')
            translation = response.get('translation', '')
            if translation:
                self._consecutive_429 = 0
                return translation
            self._log(f"Lingva returned empty for: {text[:80]}", xbmc.LOGWARNING)
            return text
        except Exception as e:
            err_str = str(e)
            if '429' in err_str:
                self._consecutive_429 += 1
            self._log(f"Lingva error for '{text[:50]}': {e}", xbmc.LOGERROR)
            raise  # Re-raise so batch handler can do backoff
    
    def translate_batch(self, texts, source_lang, target_lang):
        """Translate texts with parallel workers + rate-limit handling."""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import time
        import threading
        
        if len(texts) <= 1:
            return [self.translate(text, source_lang, target_lang) for text in texts]
        
        results = [None] * len(texts)
        lock = threading.Lock()
        rate_limited = threading.Event()
        
        def translate_one(idx, text):
            """Translate with backoff on 429."""
            # Wait if rate-limited
            while rate_limited.is_set():
                time.sleep(0.5)
            
            try:
                result = self.translate(text, source_lang, target_lang)
                return result
            except Exception as e:
                if '429' in str(e):
                    with lock:
                        self._consecutive_429 += 1
                        backoff = min(2 ** min(self._consecutive_429, 5), 30)
                    rate_limited.set()
                    self._log(f"Rate limit hit, backing off {backoff}s")
                    time.sleep(backoff)
                    rate_limited.clear()
                    # Retry once
                    try:
                        return self.translate(text, source_lang, target_lang)
                    except:
                        return text
                return text
        
        workers = min(self.MAX_WORKERS, len(texts))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_to_idx = {
                pool.submit(translate_one, i, text): i
                for i, text in enumerate(texts)
            }
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    results[idx] = future.result()
                except Exception:
                    results[idx] = texts[idx]
        
        return results


class OpenAITranslator(BaseTranslator):
    """OpenAI GPT Translation (high-quality, context-aware)."""
    
    def __init__(self, config):
        super().__init__(config)
        self.api_key = config.get('api_key', '')
        self.model = config.get('model', 'gpt-4o-mini')
        self.base_url = config.get('base_url', 'https://api.openai.com/v1').rstrip('/')
    
    def translate(self, text, source_lang, target_lang):
        """Translate text using OpenAI GPT."""
        if not self.api_key:
            raise ValueError("OpenAI API key required")
        
        result = self.translate_batch([text], source_lang, target_lang)
        return result[0] if result else text
    
    def translate_batch(self, texts, source_lang, target_lang):
        """Translate multiple texts using OpenAI."""
        if not self.api_key:
            raise ValueError("OpenAI API key required")
        
        target_name = self._get_language_name(target_lang)
        source_name = self._get_language_name(source_lang) if source_lang != 'auto' else 'the source language'
        
        # Combine texts for efficient translation
        combined = '\n---SUBTITLE_BREAK---\n'.join(texts)
        
        system_prompt = f"""You are a professional subtitle translator specializing in high-quality Latin American Spanish (español latino neutro). Translate the following subtitles from {source_name} to {target_name}.

TRANSLATION STYLE (TaMaBin Professional Standard):
- Use neutral Latin American Spanish with "tú" form (never "vos" or "vosotros")
- Natural, fluid translations that read like native speech
- Calibrate profanity/register to match the source content's genre and tone:
  * Family/animation: ZERO profanity, clean vocabulary
  * Drama: moderate ("mierda", "maldición", "demonios")
  * Horror/thriller: strong when source warrants it ("carajo", "jodido", "cabrón")
- Preserve cultural terms, proper nouns, brand names without translating
- Translate idioms to natural Spanish equivalents, not literal translations
- Use "Sólo" with accent (classical orthography)

SUBTITLE FORMAT RULES (Netflix Standard):
- Maximum 42 characters per line
- Maximum 2 lines per subtitle
- Keep translations concise - subtitles have limited display time
- Use "- " (dash + space) for dialogue lines, not dash alone
- Opening punctuation marks always: ¿ ¡
- Use <i> tags for: off-screen voices, phone calls, TV/radio, thoughts, songs
- Preserve existing HTML tags (<i>, <b>) from source

DIALOGUE FORMAT:
- Two speakers in one subtitle: first speaker on line 1, second on line 2, both with "- " prefix
- Single speaker on 2 lines: NO dash prefix

NUMBERS:
- 1-10: write in words ("tres", "siete")
- Above 10: use digits ("30 años", "127.000")
- Use period as thousands separator (127.000, not 127,000)
- Percentages in words: "42 por ciento"

CRITICAL RULES:
- Preserve the EXACT number of subtitle entries (separated by ---SUBTITLE_BREAK---)
- Do NOT add explanations, notes, or comments
- Output ONLY the translated text, nothing else"""
        
        data = {
            'model': self.model,
            'messages': [
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': combined}
            ],
            'temperature': 0.3
        }
        
        headers = {
            'Authorization': f'Bearer {self.api_key}'
        }
        
        try:
            response = self._request(f'{self.base_url}/chat/completions', data, headers)
            translated = response['choices'][0]['message']['content']
            return translated.split('\n---SUBTITLE_BREAK---\n')
        except Exception as e:
            self._log(f"OpenAI error: {e}", xbmc.LOGERROR)
            return texts
    
    def _get_language_name(self, code):
        """Get full language name from code."""
        names = {
            'sv': 'Swedish', 'en': 'English', 'de': 'German', 'fr': 'French',
            'es': 'Spanish', 'it': 'Italian', 'no': 'Norwegian', 'da': 'Danish',
            'fi': 'Finnish', 'nl': 'Dutch', 'pl': 'Polish', 'pt': 'Portuguese',
            'ru': 'Russian', 'ja': 'Japanese', 'zh': 'Chinese', 'ko': 'Korean',
            'ar': 'Arabic', 'tr': 'Turkish', 'hi': 'Hindi', 'uk': 'Ukrainian'
        }
        return names.get(code, code)


class AnthropicTranslator(BaseTranslator):
    """Anthropic Claude Translation (high-quality, context-aware)."""
    
    def __init__(self, config):
        super().__init__(config)
        self.api_key = config.get('api_key', '')
        self.model = config.get('model', 'claude-sonnet-4-6')
        self.base_url = 'https://api.anthropic.com/v1'
    
    def translate(self, text, source_lang, target_lang):
        """Translate text using Claude."""
        if not self.api_key:
            raise ValueError("Anthropic API key required")
        
        result = self.translate_batch([text], source_lang, target_lang)
        return result[0] if result else text
    
    def translate_batch(self, texts, source_lang, target_lang):
        """Translate multiple texts using Claude."""
        if not self.api_key:
            raise ValueError("Anthropic API key required")
        
        target_name = self._get_language_name(target_lang)
        source_name = self._get_language_name(source_lang) if source_lang != 'auto' else 'the source language'
        
        combined = '\n---SUBTITLE_BREAK---\n'.join(texts)
        
        system_prompt = f"""You are a professional subtitle translator specializing in high-quality Latin American Spanish (español latino neutro). Translate the following subtitles from {source_name} to {target_name}.

TRANSLATION STYLE (TaMaBin Professional Standard):
- Use neutral Latin American Spanish with "tú" form (never "vos" or "vosotros")
- Natural, fluid translations that read like native speech
- Calibrate profanity/register to match the source content's genre and tone:
  * Family/animation: ZERO profanity, clean vocabulary
  * Drama: moderate ("mierda", "maldición", "demonios")
  * Horror/thriller: strong when source warrants it ("carajo", "jodido", "cabrón")
- Preserve cultural terms, proper nouns, brand names without translating
- Translate idioms to natural Spanish equivalents, not literal translations
- Use "Sólo" with accent (classical orthography)

SUBTITLE FORMAT RULES (Netflix Standard):
- Maximum 42 characters per line
- Maximum 2 lines per subtitle
- Keep translations concise - subtitles have limited display time
- Use "- " (dash + space) for dialogue lines, not dash alone
- Opening punctuation marks always: ¿ ¡
- Use <i> tags for: off-screen voices, phone calls, TV/radio, thoughts, songs
- Preserve existing HTML tags (<i>, <b>) from source

DIALOGUE FORMAT:
- Two speakers in one subtitle: first speaker on line 1, second on line 2, both with "- " prefix
- Single speaker on 2 lines: NO dash prefix

NUMBERS:
- 1-10: write in words ("tres", "siete")
- Above 10: use digits ("30 años", "127.000")
- Use period as thousands separator (127.000, not 127,000)
- Percentages in words: "42 por ciento"

CRITICAL RULES:
- Preserve the EXACT number of subtitle entries (separated by ---SUBTITLE_BREAK---)
- Do NOT add explanations, notes, or comments
- Output ONLY the translated text, nothing else"""
        
        data = {
            'model': self.model,
            'max_tokens': 8192,
            'system': system_prompt,
            'messages': [
                {'role': 'user', 'content': combined}
            ]
        }
        
        headers = {
            'x-api-key': self.api_key,
            'anthropic-version': '2023-06-01'
        }
        
        try:
            response = self._request(f'{self.base_url}/messages', data, headers)
            translated = response['content'][0]['text']
            return translated.split('\n---SUBTITLE_BREAK---\n')
        except Exception as e:
            self._log(f"Anthropic error: {e}", xbmc.LOGERROR)
            return texts
    
    def _get_language_name(self, code):
        """Get full language name from code."""
        names = {
            'sv': 'Swedish', 'en': 'English', 'de': 'German', 'fr': 'French',
            'es': 'Spanish', 'it': 'Italian', 'no': 'Norwegian', 'da': 'Danish',
            'fi': 'Finnish', 'nl': 'Dutch', 'pl': 'Polish', 'pt': 'Portuguese',
            'ru': 'Russian', 'ja': 'Japanese', 'zh': 'Chinese', 'ko': 'Korean',
            'ar': 'Arabic', 'tr': 'Turkish', 'hi': 'Hindi', 'uk': 'Ukrainian'
        }
        return names.get(code, code)


class ArgosTranslator(BaseTranslator):
    """Argos Translate (offline, local translation using neural models)."""
    
    MAX_WORKERS = 2  # Local model, limited by CPU
    
    def __init__(self, config):
        super().__init__(config)
        self.package_path = config.get('package_path', '')
        self._argos_available = None
    
    def _check_argos(self):
        """Check if Argos Translate is available."""
        if self._argos_available is not None:
            return self._argos_available
        
        try:
            import argostranslate.package
            import argostranslate.translate
            self._argos_available = True
        except ImportError:
            self._argos_available = False
            self._log("Argos Translate not installed. Install with: pip install argostranslate", xbmc.LOGERROR)
        
        return self._argos_available
    
    def translate(self, text, source_lang, target_lang):
        """Translate text using Argos Translate (offline)."""
        if not self._check_argos():
            return text
        
        try:
            import argostranslate.translate
            
            # Get installed languages
            installed_languages = argostranslate.translate.get_installed_languages()
            source_l = next((l for l in installed_languages if l.code == source_lang), None)
            target_l = next((l for l in installed_languages if l.code == target_lang), None)
            
            if not source_l or not target_l:
                self._log(f"Language pair {source_lang}->{target_lang} not installed", xbmc.LOGERROR)
                return text
            
            translation = source_l.get_translation(target_l)
            if translation:
                return translation.translate(text)
            else:
                self._log(f"No translation available for {source_lang}->{target_lang}", xbmc.LOGERROR)
                return text
                
        except Exception as e:
            self._log(f"Argos error: {e}", xbmc.LOGERROR)
            return text
    
    def translate_batch(self, texts, source_lang, target_lang):
        """Translate multiple texts using Argos."""
        return [self.translate(text, source_lang, target_lang) for text in texts]
