# -*- coding: utf-8 -*-
import requests
import re
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon('service.translatarr')


# ----------------------------------------------------------
# Logging
# ----------------------------------------------------------
def log(msg):
    xbmc.log(f"[Translatarr] {msg}", xbmc.LOGINFO)


# ----------------------------------------------------------
# SDH Cleanup - Remove hearing-impaired annotations
# ----------------------------------------------------------
SDH_PATTERNS = [
    re.compile(r'\[.*?\]'),
    re.compile(r'\(.*?\)'),
    re.compile(r'♪.*?♪', re.DOTALL),
    re.compile(r'[♪♫]'),
    re.compile(r'#.*?#'),
]

def clean_sdh(text):
    """Remove SDH annotations from subtitle text."""
    cleaned = text
    for pattern in SDH_PATTERNS:
        cleaned = pattern.sub('', cleaned)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    cleaned = re.sub(r'^\s*-\s*$', '', cleaned).strip()
    return cleaned


# ----------------------------------------------------------
# Professional System Prompt (Netflix + Latino)
# ----------------------------------------------------------
def build_system_prompt(trg_name, src_name, expected_count):
    is_latino = "latin" in trg_name.lower() or "419" in trg_name.lower()

    base = (
        "Eres un traductor profesional de subtitulos con 20 anos de experiencia "
        "en doblaje y subtitulaje para plataformas de streaming (Netflix, Amazon, Disney+).\n\n"
    )

    if src_name and src_name.lower() != "auto-detect":
        base += f"TAREA: Traducir subtitulos de {src_name} a {trg_name}.\n\n"
    else:
        base += f"TAREA: Detectar el idioma y traducir subtitulos a {trg_name}.\n\n"

    rules = "REGLAS OBLIGATORIAS:\n\n"

    if is_latino:
        rules += (
            "1. LOCALIZACION:\n"
            "   - Espanol neutro latinoamericano (es-419)\n"
            "   - PROHIBIDO: vosotros, tio, venga, vale, mola, coche, piso, movil, gilipollas\n"
            "   - USA: ustedes, amigo, dale, ok, genial, carro, apartamento, celular, imbecil\n"
            "   - Tuteo natural (tu, no vos ni usted salvo que el contexto lo requiera)\n\n"
        )
    else:
        rules += (
            "1. LOCALIZACION:\n"
            f"   - Traduce al {trg_name} natural y fluido\n"
            "   - Usa un tono conversacional apropiado\n\n"
        )

    rules += (
        "2. CERO CENSURA:\n"
        "   - Traduce lenguaje soez, insultos y contenido adulto de forma directa y cruda\n"
        "   - NO suavices el impacto emocional. Manten la intensidad del original.\n\n"
        "3. FORMATO NETFLIX:\n"
        "   - Maximo 42 caracteres por linea\n"
        "   - Maximo 2 lineas por subtitulo\n"
        "   - No rompas frases de forma antinatural\n"
        "   - Guion largo para dialogo entre dos personas en el mismo bloque\n\n"
        "4. INTEGRIDAD (CRITICO):\n"
        "   - Traduce linea por linea estrictamente\n"
        "   - Preserva los anchors 'Lxxx:' EXACTAMENTE\n"
        f"   - Devuelve EXACTAMENTE {expected_count} lineas\n"
        "   - NO saltes, combines ni omitas ninguna linea\n"
        "   - NO agregues comentarios ni explicaciones\n\n"
        "5. SALIDA:\n"
        "   - Devuelve SOLO las lineas traducidas con sus prefijos Lxxx:\n"
    )

    return base + rules


# ----------------------------------------------------------
# Base Translator
# ----------------------------------------------------------
class BaseTranslator:

    def _get_temperature(self):
        try:
            temp = float(ADDON.getSetting('temp') or 0.15)
            return max(0.0, min(temp, 1.0))
        except:
            return 0.15

    def _scrub(self, raw_text, expected):
        if not raw_text:
            return None
        lines = raw_text.splitlines()
        cleaned = []
        for line in lines:
            match = re.match(r'^\s*L(\d{3}):\s*(.*)', line)
            if match:
                cleaned.append(match.group(2).strip())
        return cleaned if len(cleaned) == expected else None

    def translate_batch(self, text_list, expected_count):
        raise NotImplementedError

    def calculate_cost(self, input_tokens, output_tokens):
        raise NotImplementedError

    def get_model_string(self):
        raise NotImplementedError


# ==========================================================
# GEMINI TRANSLATOR
# ==========================================================
class GeminiTranslator(BaseTranslator):

    PRICING = {
        "gemini-2.0-flash": (0.0000001, 0.0000004),
        "gemini-1.5-flash": (0.0000000, 0.0000000),
        "gemini-2.5-flash": (0.0000003, 0.0000025),
    }

    def __init__(self):
        self.api_key = ADDON.getSetting('api_key')
        self.temperature = self._get_temperature()
        self.fast_mode = False
        self.model = ADDON.getSetting('gemini_dynamic_model') or ''
        if not self.model:
            model_map = {
                "Gemini 2.5 Flash": "gemini-2.5-flash",
                "Fast Mode - Gemini 2.5 Flash": "gemini-2.5-flash",
                "Gemini 2.0 Flash": "gemini-2.0-flash",
                "Gemini 2.0 Flash (Legacy)": "gemini-2.0-flash",
                "Gemini 1.5 Flash": "gemini-1.5-flash",
                "Gemini 1.5 Flash (Legacy)": "gemini-1.5-flash"
            }
            selected_model = ADDON.getSetting('model')
            self.model = model_map.get(selected_model, "gemini-2.5-flash")
            self.fast_mode = selected_model == "Fast Mode - Gemini 2.5 Flash"

    def translate_batch(self, text_list, expected_count):
        if not self.api_key:
            log("Gemini API key missing")
            return None, 0, 0

        from languages import get_lang_params, get_active_language_setting
        src_name, _ = get_lang_params(get_active_language_setting(ADDON, "Gemini", 'source'))
        trg_name, _ = get_lang_params(get_active_language_setting(ADDON, "Gemini", 'target'))

        prefixed = [f"L{i:03}: {t}" for i, t in enumerate(text_list)]
        input_text = "\n".join(prefixed)
        system_prompt = build_system_prompt(trg_name, src_name, expected_count)

        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.model}:generateContent?key={self.api_key}"
        )
        payload = {
            "contents": [{"parts": [{"text": f"{system_prompt}\n\n{input_text}"}]}],
            "generationConfig": {"temperature": self.temperature}
        }
        if self.fast_mode and "2.5" in self.model:
            payload["generationConfig"]["thinkingConfig"] = {"thinkingBudget": 0}

        try:
            r = requests.post(url, json=payload, timeout=30)
            if r.status_code != 200:
                log(f"Gemini error ({self.model}): {r.status_code} | {r.text[:500]}")
                return None, 0, 0
            data = r.json()
            raw = (data.get("candidates", [{}])[0]
                   .get("content", {}).get("parts", [{}])[0]
                   .get("text", "").strip())
            translated = self._scrub(raw, expected_count)
            if not translated:
                log(f"Gemini scrub failed: expected {expected_count} lines")
                return None, 0, 0
            usage = data.get("usageMetadata", {})
            return translated, usage.get("promptTokenCount", 0), usage.get("candidatesTokenCount", 0)
        except Exception as e:
            log(f"Gemini exception ({self.model}): {e}")
            return None, 0, 0

    def calculate_cost(self, input_tokens, output_tokens):
        in_price, out_price = self.PRICING.get(self.model, (0, 0))
        return (input_tokens * in_price) + (output_tokens * out_price)

    def get_model_string(self):
        suffix = " Fast" if self.fast_mode else ""
        return f"Gemini ({self.model}{suffix})"


# ==========================================================
# OPENAI TRANSLATOR
# ==========================================================
class OpenAITranslator(BaseTranslator):

    PRICING = {
        "gpt-4o-mini": (0.00000015, 0.00000060),
        "gpt-4o": (0.0000025, 0.0000100),
        "gpt-5-mini": (0.00000025, 0.0000020),
    }

    def __init__(self):
        self.api_key = ADDON.getSetting('openai_api_key')
        self.temperature = self._get_temperature()
        self.model = ADDON.getSetting('openai_dynamic_model') or ''
        if not self.model:
            model_map = {"gpt-4o-mini": "gpt-4o-mini", "gpt-4o": "gpt-4o", "gpt-5-mini": "gpt-5-mini"}
            self.model = model_map.get(ADDON.getSetting('openai_model'), "gpt-4o-mini")

    def translate_batch(self, text_list, expected_count):
        if not self.api_key:
            log("OpenAI API key missing")
            return None, 0, 0
        from languages import get_lang_params, get_active_language_setting
        src_name, _ = get_lang_params(get_active_language_setting(ADDON, "OpenAI", 'source'))
        trg_name, _ = get_lang_params(get_active_language_setting(ADDON, "OpenAI", 'target'))
        prefixed = [f"L{i:03}: {t}" for i, t in enumerate(text_list)]
        input_text = "\n".join(prefixed)
        system_prompt = build_system_prompt(trg_name, src_name, expected_count)
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": input_text}
            ],
            "temperature": self.temperature
        }
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        try:
            r = requests.post("https://api.openai.com/v1/chat/completions",
                              headers=headers, json=payload, timeout=30)
            if r.status_code != 200:
                log(f"OpenAI error ({self.model}): {r.status_code} | {r.text[:500]}")
                return None, 0, 0
            data = r.json()
            raw = (data.get("choices", [{}])[0].get("message", {}).get("content", "").strip())
            translated = self._scrub(raw, expected_count)
            if not translated:
                log(f"OpenAI scrub failed: expected {expected_count} lines")
                return None, 0, 0
            usage = data.get("usage", {})
            return translated, usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0)
        except Exception as e:
            log(f"OpenAI exception ({self.model}): {e}")
            return None, 0, 0

    def calculate_cost(self, input_tokens, output_tokens):
        in_price, out_price = self.PRICING.get(self.model, (0, 0))
        return (input_tokens * in_price) + (output_tokens * out_price)

    def get_model_string(self):
        return f"OpenAI ({self.model})"


# ==========================================================
# DEEPL TRANSLATOR (Free & Pro)
# ==========================================================
class DeepLTranslator(BaseTranslator):

    PRICE_PER_CHARACTER = 0.0
    STATUS_MESSAGES = {
        400: "Bad request.", 403: "Auth failed.", 413: "Too large.",
        429: "Rate limit.", 456: "Quota exceeded.", 503: "Unavailable.",
    }

    def __init__(self, pro=False):
        self.pro = pro
        self.api_key = ADDON.getSetting('deepl_api_key')
        self.endpoint = "https://api.deepl.com/v2/translate" if pro else "https://api-free.deepl.com/v2/translate"
        if pro:
            self.PRICE_PER_CHARACTER = 0.00002

    def _get_lang_codes(self):
        from languages import get_lang_params, get_provider_language_code, get_active_language_setting
        provider = "DeepL Pro" if self.pro else "DeepL"
        source_value = get_active_language_setting(ADDON, provider, 'source')
        target_value = get_active_language_setting(ADDON, provider, 'target')
        src_name, _ = get_lang_params(source_value)
        trg_name, _ = get_lang_params(target_value)
        src_code = get_provider_language_code("DeepL", source_value, allow_auto_detect=True)
        trg_code = get_provider_language_code("DeepL", target_value)
        if not trg_code:
            log(f"DeepL target not supported: {trg_name}")
            return None, None, src_name, trg_name
        return src_code, trg_code, src_name, trg_name

    def translate_batch(self, text_list, expected_count):
        if not self.api_key:
            log("DeepL API key missing")
            return None, 0, 0
        src_code, trg_code, src_name, trg_name = self._get_lang_codes()
        if not trg_code:
            return None, 0, 0
        if src_name.lower() != "auto-detect" and not src_code:
            return None, 0, 0

        prefixed = [f"L{i:03}: {t}" for i, t in enumerate(text_list)]
        payload = {"text": prefixed, "target_lang": trg_code, "split_sentences": "0"}
        if src_code:
            payload["source_lang"] = src_code
        if trg_code in ("ES", "ES-419"):
            payload["formality"] = "less"

        headers = {"Authorization": "DeepL-Auth-Key " + self.api_key, "Content-Type": "application/json"}
        try:
            r = requests.post(self.endpoint, headers=headers, json=payload, timeout=30)
            if r.status_code != 200:
                log(f"DeepL error: {r.status_code} | {self.STATUS_MESSAGES.get(r.status_code, r.text[:300])}")
                return None, 0, 0
            data = r.json()
            translated = [item.get("text", "").strip() for item in data.get("translations", [])]
            if len(translated) != expected_count or any(not line for line in translated):
                log(f"DeepL returned {len(translated)} lines, expected {expected_count}")
                return None, 0, 0
            return translated, data.get("billed_characters", 0), 0
        except Exception as e:
            log(f"DeepL exception: {e}")
            return None, 0, 0

    def calculate_cost(self, input_tokens, output_tokens):
        return float(input_tokens) * self.PRICE_PER_CHARACTER

    def get_model_string(self):
        return "DeepL Pro" if self.pro else "DeepL Free"


# ==========================================================
# GOOGLE TRANSLATE API
# ==========================================================
class GoogleTranslateTranslator(BaseTranslator):

    PRICE_PER_CHARACTER = 0.00002

    def __init__(self):
        self.api_key = ADDON.getSetting('google_translate_api_key')

    def translate_batch(self, text_list, expected_count):
        if not self.api_key:
            log("Google Translate API key missing")
            return None, 0, 0
        from languages import get_lang_params, get_provider_language_code, get_active_language_setting
        source_value = get_active_language_setting(ADDON, "Google Translate", 'source')
        target_value = get_active_language_setting(ADDON, "Google Translate", 'target')
        src_name, _ = get_lang_params(source_value)
        trg_name, _ = get_lang_params(target_value)
        src_code = get_provider_language_code("Google Translate", source_value, allow_auto_detect=True)
        trg_code = get_provider_language_code("Google Translate", target_value)
        if not trg_code:
            log(f"Google Translate target not supported: {trg_name}")
            return None, 0, 0

        prefixed = [f"L{i:03}: {t}" for i, t in enumerate(text_list)]
        url = f"https://translation.googleapis.com/language/translate/v2?key={self.api_key}"
        payload = {"q": prefixed, "target": trg_code, "format": "text"}
        if src_code:
            payload["source"] = src_code

        try:
            r = requests.post(url, json=payload, timeout=30)
            if r.status_code != 200:
                log(f"Google Translate error: {r.status_code} | {r.text[:500]}")
                return None, 0, 0
            data = r.json()
            translations = data.get("data", {}).get("translations", [])
            translated = [t.get("translatedText", "").strip() for t in translations]
            if len(translated) != expected_count or any(not line for line in translated):
                log(f"Google Translate returned {len(translated)} lines, expected {expected_count}")
                return None, 0, 0
            return translated, sum(len(t) for t in prefixed), 0
        except Exception as e:
            log(f"Google Translate exception: {e}")
            return None, 0, 0

    def calculate_cost(self, input_tokens, output_tokens):
        return float(input_tokens) * self.PRICE_PER_CHARACTER

    def get_model_string(self):
        return "Google Translate"


# ==========================================================
# LIBRETRANSLATE TRANSLATOR
# ==========================================================
class LibreTranslateTranslator(BaseTranslator):

    def __init__(self):
        self.base_url = (ADDON.getSetting('libretranslate_url') or '').strip()
        self.api_key = (ADDON.getSetting('libretranslate_api_key') or '').strip()

    def _get_endpoint(self):
        if not self.base_url or not self.base_url.startswith(("http://", "https://")):
            return None
        return self.base_url.rstrip("/") + "/translate"

    def translate_batch(self, text_list, expected_count):
        endpoint = self._get_endpoint()
        if not endpoint:
            return None, 0, 0
        from languages import get_lang_params, get_active_language_setting
        _, src_code = get_lang_params(get_active_language_setting(ADDON, "LibreTranslate", 'source'))
        _, trg_code = get_lang_params(get_active_language_setting(ADDON, "LibreTranslate", 'target'))
        prefixed = [f"L{i:03}: {t}" for i, t in enumerate(text_list)]
        payload = {"q": prefixed, "source": src_code, "target": trg_code, "format": "text"}
        if self.api_key:
            payload["api_key"] = self.api_key
        try:
            r = requests.post(endpoint, headers={"Content-Type": "application/json"}, json=payload, timeout=30)
            if r.status_code != 200:
                log(f"LibreTranslate error: {r.status_code}")
                return None, 0, 0
            data = r.json()
            translated = data.get("translatedText", [])
            if isinstance(translated, str):
                translated = self._scrub(translated, expected_count)
            else:
                translated = [str(item).strip() for item in translated]
            if not translated or len(translated) != expected_count:
                return None, 0, 0
            return translated, sum(len(item) for item in prefixed), 0
        except Exception as e:
            log(f"LibreTranslate exception: {e}")
            return None, 0, 0

    def calculate_cost(self, input_tokens, output_tokens):
        return 0.0

    def get_model_string(self):
        return "LibreTranslate"


# ==========================================================
# DYNAMIC MODEL LISTING
# ==========================================================
def fetch_gemini_models(api_key):
    try:
        r = requests.get(f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}", timeout=10)
        if r.status_code != 200:
            return []
        models = []
        for m in r.json().get("models", []):
            name = m.get("name", "").replace("models/", "")
            methods = [sm.get("name", "") for sm in m.get("supportedGenerationMethods", [])]
            if "generateContent" in methods:
                models.append((name, m.get("displayName", name)))
        return sorted(models, key=lambda x: x[1])
    except Exception:
        return []

def fetch_openai_models(api_key):
    try:
        r = requests.get("https://api.openai.com/v1/models",
                         headers={"Authorization": f"Bearer {api_key}"}, timeout=10)
        if r.status_code != 200:
            return []
        models = []
        for m in r.json().get("data", []):
            mid = m.get("id", "")
            if mid.startswith("gpt-") and "realtime" not in mid and "audio" not in mid:
                models.append((mid, mid))
        return sorted(models, key=lambda x: x[0])
    except Exception:
        return []


# ==========================================================
# PUBLIC API
# ==========================================================
def _get_translator():
    provider = ADDON.getSetting('provider')
    if provider == "OpenAI":
        return OpenAITranslator()
    if provider == "DeepL":
        return DeepLTranslator(pro=False)
    if provider == "DeepL Pro":
        return DeepLTranslator(pro=True)
    if provider == "Google Translate":
        return GoogleTranslateTranslator()
    if provider == "LibreTranslate":
        return LibreTranslateTranslator()
    return GeminiTranslator()

def translate_batch(text_list, expected_count):
    return _get_translator().translate_batch(text_list, expected_count)

def calculate_cost(input_tokens, output_tokens):
    return _get_translator().calculate_cost(input_tokens, output_tokens)

def get_model_string():
    return _get_translator().get_model_string()
