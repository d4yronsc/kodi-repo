# -*- coding: utf-8 -*-
import sys
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "service.translatarr"
ADDON = xbmcaddon.Addon(ADDON_ID)


def log(message, level="info"):
    levels = {"debug": xbmc.LOGDEBUG, "info": xbmc.LOGINFO,
              "warning": xbmc.LOGWARNING, "error": xbmc.LOGERROR}
    xbmc.log(f"[Translatarr][Launcher] {message}", levels.get(level, xbmc.LOGINFO))


def show_changelog():
    try:
        addon_path = ADDON.getAddonInfo('path')
        changelog_path = os.path.join(addon_path, 'changelog.txt')
        if xbmcvfs.exists(changelog_path):
            f = xbmcvfs.File(changelog_path)
            content = f.read()
            f.close()
            if isinstance(content, bytes):
                content = content.decode("utf-8", errors="replace")
        else:
            content = "No changelog available."
        xbmcgui.Dialog().textviewer(f"{ADDON.getAddonInfo('name')} - Change Log", content)
    except Exception as e:
        log(f"Failed to open changelog: {e}", "error")


def force_translate():
    """Send force_translate signal to the running service with confirmation."""
    log("Force translate requested via launcher")

    if not xbmc.Player().isPlayingVideo():
        xbmcgui.Dialog().ok("Translatarr", "No video is currently playing.")
        return

    provider = ADDON.getSetting('provider') or 'Gemini'
    from languages import get_lang_params, get_active_language_setting
    trg_name, _ = get_lang_params(get_active_language_setting(ADDON, provider, 'target'))

    result = xbmcgui.Dialog().yesno(
        "Translatarr",
        f"Translate subtitle to {trg_name}?",
        yeslabel="Translate",
        nolabel="Cancel"
    )

    if result:
        log("User confirmed translation, sending signal")
        xbmc.executebuiltin('NotifyAll(service.translatarr, force_translate)')
    else:
        log("User cancelled translation")


def fetch_models():
    """Fetch available models from the selected provider and let user choose."""
    import translator as tr

    provider = ADDON.getSetting('provider')

    if provider in ("Gemini", ""):
        api_key = ADDON.getSetting('api_key')
        if not api_key:
            xbmcgui.Dialog().ok("Translatarr", "Gemini API key is not set.")
            return
        models = tr.fetch_gemini_models(api_key)
        setting_key = 'gemini_dynamic_model'
    elif provider == "OpenAI":
        api_key = ADDON.getSetting('openai_api_key')
        if not api_key:
            xbmcgui.Dialog().ok("Translatarr", "OpenAI API key is not set.")
            return
        models = tr.fetch_openai_models(api_key)
        setting_key = 'openai_dynamic_model'
    else:
        xbmcgui.Dialog().ok("Translatarr", f"{provider} does not support model selection.")
        return

    if not models:
        xbmcgui.Dialog().ok("Translatarr", "Could not fetch models. Check your API key.")
        return

    display_names = [m[1] for m in models]
    model_ids = [m[0] for m in models]

    choice = xbmcgui.Dialog().select(f"Select {provider} Model", display_names)
    if choice >= 0:
        selected_id = model_ids[choice]
        ADDON.setSetting(setting_key, selected_id)
        xbmcgui.Dialog().notification("Translatarr", f"Model: {display_names[choice]}",
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        log(f"User selected model: {selected_id}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        param = sys.argv[1]
        if param == "show_changelog":
            show_changelog()
        elif param == "force_translate":
            force_translate()
        elif param == "fetch_models":
            fetch_models()
        else:
            ADDON.openSettings()
    else:
        ADDON.openSettings()
